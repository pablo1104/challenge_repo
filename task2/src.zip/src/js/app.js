define(
  function(require){
  	var _ = require('underscore');
    var $ = require('jquery');
    var Backbone = require('backbone');
    var Marionette = require('marionette');

	var CrimeApp = new Marionette.Application();

	CrimeApp.addRegions({
	  filters: "#filters",
	  items: "#items",
	  map: "#maps"
	});

	CrimeApp.addInitializer(function(options){
	  
	});
	//CrimeApp.start();
	console.log(CrimeApp);
	return CrimeApp;

});