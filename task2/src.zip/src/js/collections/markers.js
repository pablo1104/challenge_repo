define(
  ['backbone', 'marionette','models/marker'],
  function( Backbone, Marionette, Marker){
	var markers =  Backbone.Collection.extend({
	  model: Marker,

	  initialize: function(){

        },
	});
	
	return markers;

});