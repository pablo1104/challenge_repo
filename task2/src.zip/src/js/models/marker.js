define(
  ['backbone' ],
  function( Backbone){
	var Marker = Backbone.Model.extend({
		defaults: {
            //used to keep the item synced between the map and the result list
            selected: false
        },

	});

	return Marker;

});