define(
  ['app','jquery','underscore','backbone','marionette','handlebars','text!templates/filters.html' ],
  function(app,$, _, Backbone, Marionette, Handleblars, FilterTemplate){
	var FiltersView = Marionette.ItemView.extend({
	  type: 'handlebars',
	  template: Handleblars.compile(FilterTemplate),
	  className: 'filters',
	 
	  events: {

	  },
	  ui: {
            category: '[name=category]'
      },
	  initialize: function(){
	    
	  },
	  events: {
            'submit':'filter'
        },
	  serializeData: function(){
	  	 
	    viewData = { name: 'Pablo Alba', options_cats: this.options.options_cats };
	    
	    return viewData;
	  },

	  filter:function(e){
	  	var cat = this.ui.category.val();
	  	e.preventDefault();
	  	console.log(cat);
	  	app.vent.trigger('filter:new', cat);
	  	app.vent.trigger('filter_map:new', cat);

	  	
	  }		  

	});

	return FiltersView;

});